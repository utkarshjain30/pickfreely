<!-- Start Mobile Menu -->
<div class="mobile-menu hidden-md hidden-lg">
        <nav>
            <ul>
                <li class=""><a href="index.html">Home</a></li>
                @foreach ($Categories as $item)
                <li><a href="javascript.void(0)">{{$item->name}}</a>
                    <ul class="">
                        @foreach (renderMainCategory($item->id) as $mainitem)                      
                        <li><a href="javascript.void(0)">{{$mainitem->name}}</a>
                            <ul>
                                @foreach (renderSubCategory($mainitem->id) as $subitem)
                            <li><a href="/list?subcat={{$subitem->id}}">{{$subitem->name}}</a></li>  
                                @endforeach														
                            </ul>
                        </li>
                        @endforeach  
                    </ul>
                </li>
                @endforeach
                
                <li class=""><a href="">Pages</a>
                    <ul class="">
                        <li><a href="blog.html">Blog</a></li>
                        <li><a href="blog-details.html">Blog Details</a></li>
                        <li><a href="cart.html">Cart</a></li>
                        <li><a href="checkout.html">Checkout</a></li>
                        <li><a href="contact.html">Contact</a></li>
                        <li><a href="shop.html">Shop</a></li>
                        <li><a href="shop-list.html">Shop List</a></li>
                        <li><a href="product-details.html">Product Details</a></li>
                        <li><a href="my-account.html">My Account</a></li>
                        <li><a href="wishlist.html">Wishlist</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div><!-- End Mobile Menu -->