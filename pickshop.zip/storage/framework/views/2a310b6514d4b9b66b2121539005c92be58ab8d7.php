<?php $__env->startSection('contents'); ?>

<!-- Entry Header Area -->
<div class="entry-header-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="entry-header">
					<h1 class="entry-title">Checkout</h1>
				</div>
			</div>
		</div>
	</div>
</div><!-- Entry Header Area -->
<!-- Coupon Area -->
<div class="coupon-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="coupon-accordion">
					<!-- ACCORDION START -->
					<h3>Returning customer? <span id="showlogin">Click here to login</span></h3>
					<div id="checkout-login" class="coupon-content">
						<div class="coupon-info">
							<p class="coupon-text">Quisque gravida turpis sit amet nulla posuere lacinia. Cras sed est sit amet ipsum luctus.</p>
							<form action="#">
								<p class="form-row-first">
									<label>Username or email <span class="required">*</span></label>
									<input type="text" />
								</p>
								<p class="form-row-last">
									<label>Password  <span class="required">*</span></label>
									<input type="text" />
								</p>
								<p class="form-row">					
									<input type="submit" value="Login" />
									<label>
										<input type="checkbox" />
											Remember me 
									</label>
								</p>
								<p class="lost-password">
									<a href="#">Lost your password?</a>
								</p>
							</form>
						</div>
					</div><!-- ACCORDION END -->	
					<!-- ACCORDION START -->
					<h3>Have a coupon? <span id="showcoupon">Click here to enter your code</span></h3>
					<div id="checkout_coupon" class="coupon-checkout-content">
						<div class="coupon-info">
							<form action="#">
								<p class="checkout-coupon">
									<input type="text" placeholder="Coupon code" />
									<input type="submit" value="Apply Coupon" />
								</p>
							</form>
						</div>
					</div><!-- ACCORDION END -->						
				</div>
			</div>
		</div>
	</div>
</div><!-- End Coupon Area -->

<!-- Checkout Area -->
<div class="checkout-area">
	<div class="container">
		<div class="row">
			
			<?php echo Form::open(['url' => '/confirm', 'method' => 'post']); ?>

				<?php echo csrf_field(); ?>
				<div class="col-lg-6 col-md-6">
					<div class="checkbox-form">						
						<h3>Shipping Details</h3>
						<div class="row">
							<div class="col-md-6">
								<div class="checkout-form-list">
									<?php echo e(Form::label('text', 'First Name')); ?>

									<?php echo e(Form::text('First Name','',array('required' => 'required'))); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="checkout-form-list">
										<?php echo e(Form::label('text', 'Last Name')); ?>

										<?php echo e(Form::text('Last Name')); ?>

								</div>
							</div>
							<div class="col-md-12">
								<div class="checkout-form-list">
										<?php echo e(Form::label('text', 'Address')); ?>

										<?php echo e(Form::text('Address_1','',array('required' => 'required'))); ?>

								</div>
							</div>
							<div class="col-md-12">
								<div class="checkout-form-list">
										<?php echo e(Form::text('Address_2')); ?>

								</div>
							</div>
							<div class="col-md-12">
								<div class="checkout-form-list">
										<?php echo e(Form::label('text', 'City/Town')); ?>

										<?php echo e(Form::text('City','',array('required' => 'required'))); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="checkout-form-list">
										<?php echo e(Form::label('text', 'State')); ?>

										<?php echo e(Form::text('State','',array('required' => 'required'))); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="checkout-form-list">
										<?php echo e(Form::label('text', 'Postcode')); ?>

										<?php echo e(Form::text('Postcode','',array('required' => 'required'))); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="checkout-form-list">
										<?php echo e(Form::label('email', 'email')); ?>

										<?php echo e(Form::email('Email', null, $attributes = ['required'])); ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="checkout-form-list">
										<?php echo e(Form::label('text', 'Mobile')); ?>

										<?php echo e(Form::text('Mobile','Mobile',array('required' => 'required'))); ?>

								</div>
							</div>
							<div class="col-md-12">
								<div class="checkout-form-list create-acc">	
									<input id="cbox" type="checkbox" />
									<label>Create an account?</label>
								</div>
								<div id="cbox_info" class="checkout-form-list create-account">
									<p>Create an account by entering the information below. If you are a returning customer please login at the top of the page.</p>
									<label>Account password  <span class="required">*</span></label>
									<input type="password" placeholder="password" />	
								</div>
							</div>								
						</div>													
					</div>
				</div>	
				<div class="col-lg-6 col-md-6">
					<div class="your-order">
						<h3>Your order</h3>
						<div class="your-order-table table-responsive">
							<table>
								<thead>
									<tr>
										<th class="product-name">Product</th>
										<th class="product-total">Total</th>
									</tr>							
								</thead>
								<tbody>
									<?php $cartCollection = Cart::getContent(); ?>
									<?php $__currentLoopData = $cartCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="cart_item">
										<td class="product-name">
										<?php echo e($item->name); ?> <strong class="product-quantity"> × <?php echo e($item->quantity); ?></strong>
										</td>
										<td class="product-total">
										<?php $totalPrice = ($item->quantity)*($item->price)?>
										<span class="amount">Rs. <?php echo e($totalPrice); ?>/-</span>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</tbody>
								<tfoot>
									<tr class="cart-subtotal">
										<th>Cart Subtotal</th>
										<td><span class="amount">Rs. <?php echo e(Cart::getSubTotal()); ?>/-</span></td>
									</tr>
									<tr class="shipping">
										<th>Shipping</th>
										<td>
											<ul>
											<?php if(Cart::getTotal() > 500): ?>
											<li>
												<label>Flat Rate: <span class="amount">Rs. 200/-</span></label>
											</li>
											<?php
											//$id = Cart::getContent()->id;
											// $price = Cart::getTotal() + 200;
											// Cart::update(array(
											// 	'price'=>$price,
											// ));
											?>	
											<?php else: ?>
											<li>
												<label>Free Shipping</label>
											</li>
											<?php endif; ?>
												
											</ul>
										</td>
									</tr>
									<tr class="order-total">
										<th>Order Total</th>
									<td><strong><span class="amount">Rs. <?php echo e(Cart::getTotal()); ?>/-</span></strong>
										<?php echo e(Form::text('totalPrice', Cart::getTotal(),array('hidden'=>'hidden'))); ?>

										</td>
									</tr>								
								</tfoot>
							</table>
						</div>
						<div class="payment-method">
								<!-- ACCORDION START -->
								<p>Direct Bank Transfer</p>
								<?php echo e(Form::radio('payment', 'Cash On Delivery', true)); ?>

								<!-- ACCORDION START -->
								<p>PayPal <img src="img/logo/payment-2.png" alt=""></p>
								<?php echo e(Form::radio('payment', 'Online Payment')); ?>

							<div class="order-button-payment">
									<?php echo e(Form::submit('Place Order')); ?>

							</div>
						</div>
					</div>
				</div>
			<?php echo Form::close(); ?>


		</div>
	</div>
</div><!-- End checkout Area -->	
		
			
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>