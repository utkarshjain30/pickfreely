<?php $__env->startSection('contents'); ?>
	

        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		
		
		<!-- Main Slider Area -->
		<div class="main-slider-area">
			<!-- Main Slider -->
			<div class="main-slider">
				<div class="slider">
					<div id="mainSlider" class="nivoSlider slider-image">
						<img src="<?php echo e(URL::to("assets/img/slider/slider2.jpg")); ?>" alt="main slider" title="#htmlcaption1"/>
						<img src="<?php echo e(URL::to("assets/img/slider/slider1.jpg")); ?>" alt="main slider" title="#htmlcaption2"/>
					</div>
					<!-- Slider Caption One -->
					<div id="htmlcaption1" class="nivo-html-caption slider-caption-1 hidden-xs">
						<div class="slider-progress"></div>									
						<div class="slide-text">
							<div class="middle-text">
								<div class="cap-title wow zoomInUp" data-wow-duration=".9s" data-wow-delay="0s">
									<h2>At Finally started...</h2>
								</div>
								<div class="cap-dec">
									<h1 class="wow zoomInUp" data-wow-duration="1.1s" data-wow-delay="0s">Huge sale</h1>
									<p class="wow zoomInUp" data-wow-duration="1.3s" data-wow-delay="0s"> up to 70% off Fahion collection Shop now</p>
								</div>	
								<div class="cap-readmore wow zoomInUp" data-wow-duration="1.3s" data-wow-delay=".3s">
									<a href="#">Shop Now</a>
								</div>	
							</div>	
						</div>
					</div>
					<!-- Slider Caption Two -->
					<div id="htmlcaption2" class="nivo-html-caption slider-caption-2 hidden-xs">
						<div class="slider-progress"></div>					
						<div class="slide-text">
							<div class="middle-text">
								<div class="cap-title wow zoomInRight" data-wow-duration=".9s" data-wow-delay="0s">
									<h2>At Finally started...</h2>
								</div>
								<div class="cap-dec">
									<h1 class="cap-dec wow zoomInRight" data-wow-duration="1.1s" data-wow-delay="0s">Huge sale</h1>
									<p class="cap-dec wow zoomInRight" data-wow-duration="1.3s" data-wow-delay="0s"> up to 70% off Fahion collection Shop now</p>
								</div>	
								<div class="cap-readmore wow zoomInRight" data-wow-duration=".9s" data-wow-delay=".5s">
									<a href="#">Shop Now</a>
								</div>	
							</div>	
						</div>
					</div>
				</div>
			</div><!-- End Main Slider -->
		</div><!-- End Main Slider Area -->		
		<!-- Product Box Area -->
		<div class="product-box-area">
			<div class="container">
				<!-- Product Box -->
				<div class="product-box">
					<!-- Single Product Box -->
					<div class="single-product-box">
						<div class="product-box-img">
							<a href="#"><img src="<?php echo e(URL::to("assets/img/product-box/pb1.png")); ?>" alt="product"></a>							
						</div>
						<div class="product-box-content">				
							<h2>Clothing</h2>
							<p>Fashiong trending 2015</p>
							<a href="#">shop now</a>
						</div>
					</div>
					<!-- Single Product Box -->
					<div class="single-product-box single-product-box-two">
						<div class="product-box-content">				
							<h2>hand Bags</h2>
							<p>Fashiong trending 2015</p>
							<a href="#">shop now</a>
						</div>
						<div class="product-box-img">
							<a href="#"><img src="<?php echo e(URL::to("assets/img/product-box/pb2.png")); ?>" alt="product"></a>							
						</div>
					</div>
					<!-- Single Product Box -->
					<div class="single-product-box single-product-box-three">
						<div class="product-box-img">
							<a href="#"><img src="<?php echo e(URL::to("assets/img/product-box/pb3.png")); ?>" alt="product"></a>							
						</div>
						<div class="product-box-content">				
							<h2>Shoes</h2>
							<p>Fashiong trending 2015</p>
							<a href="#">shop now</a>
						</div>
					</div>
				</div><!-- End Product Box -->
			</div>
		</div><!-- End Product Box Area -->
		<!-- Product area -->
		<div class="product-area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<!-- Product Top Bar -->
						<div class="product-top-bar customize-tab-bar">
							<!-- Tab Button -->
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation" class="active"><a href="#p-bestseller" data-toggle="tab"><i class="fa fa-pencil-square-o"></i>bestseller</a></li>
								<li role="presentation"><a href="#p-new" data-toggle="tab"><i class="fa fa-star"></i>New Products</a></li>
								<li role="presentation"><a href="#p-random" data-toggle="tab"><i class="fa fa-picture-o"></i>Random Products</a></li>
							</ul><!-- End Tab Button -->
						</div><!-- End Product Top Bar -->
					</div>
					<div class="col-md-12">
						<!-- Single Product area -->
						<div class="single-product-area c-carousel-button">	
							<!-- Tab Content -->
							<div class="tab-content">
								<!-- Tab Pane One -->
								<div class="tab-pane active" id="p-bestseller">
									<div class="row">
										<!-- Single Product Carousel-->
										<div id="single-product-bestseller" class="owl-carousel">
											<!-- Start Single Product Column-->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="<?php echo e(URL::to("assets/img/product/sp2.jpg")); ?>" alt="product">
															<img class="secondary-img" src="<?php echo e(URL::to("assets/img/product/sp1.jpg")); ?>" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp3.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp4.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price"><span>$205.00</span> $155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp1.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp5.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$167.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp6.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp19.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$333.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp7.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp8.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$80.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp9.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp6.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price"><span>$124.00</span> $134.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp1.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp2.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp10.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp8.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
										</div><!-- End Single Product Carousel-->
									</div>
								</div><!-- End Tab Pane One -->
								<!-- Tab Pane Two -->
								<div class="tab-pane" id="p-new">
									<div class="row">
										<!-- Single Product Carousel-->
										<div id="single-product-new" class="owl-carousel">
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp15.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp12.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price"><span>$222.00</span> $143.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp13.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp7.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp17.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp16.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price"><span>$100.00</span> $70.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp11.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp12.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp16.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp17.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp18.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp18.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp1.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp2.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp19.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp20.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
										</div><!-- End Single Product Carousel-->
									</div>
								</div><!-- End Tab Pane Two -->
								<!-- Tab Pane Three -->
								<div role="tabpanel" class="tab-pane" id="p-random">
									<div class="row">
										<!-- Single Product Carousel-->
										<div id="single-product-random" class="owl-carousel">
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp20.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp21.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp17.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp11.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price"><span>$205.00</span> $155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp10.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp2.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp16.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp20.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price"><span>$80.00</span> $65.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp18.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp19.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp11.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp21.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp1.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp2.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp13.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp5.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
										</div><!-- End Single Product Carousel-->
									</div>
								</div><!-- End Tab Pane Three -->
							</div><!-- End Tab Content -->
						</div><!-- End Single Product area -->
					</div>
				</div>
			</div>
		</div><!-- End Product area -->
		<!-- Single Banner area -->
		<div class="single-banner-area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="singler-banner banner-add">
							<a href="#">
								<img src="img/banner/b1.png" alt="banner">
							</a>
						</div>
					</div>
				</div>
			</div>
		</div><!-- End Single Banner area -->
		<!-- Brand Product area -->
		<div class="brand-products-area">
			<div class="container">
				<div class="row">
					<!-- Brand Product Column -->
					<div class="col-md-6 col-sm-6">
						<div class="brand-products brand-product-shoes c-carousel-button">
							<div class="row">
								<div class="col-md-12">
									<div class="products-head">
										<div class="products-head-title">
											<i class="fa fa-picture-o"></i>
											<h2>brand shoes</h2>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<!-- Single Product Carousel-->
								<div id="product-brand-shoes" class="owl-carousel">
									<!-- Start Single Product Column -->
									<div class="col-md-6">
										<div class="single-product">
											<div class="single-product-img">
												<a href="#">
													<img class="primary-img" src="img/product/sp4.jpg" alt="product">
													<img class="secondary-img" src="img/product/sp9.jpg" alt="product">
												</a>
											</div>
											<div class="single-product-content">
												<div class="product-content-head">
													<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
													<p class="product-price">$155.00</p>
												</div>
												<div class="product-bottom-action">
													<div class="product-action">
														<div class="action-button">
															<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
														</div>
														<div class="action-view">
															<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div><!-- End Single Product Column -->
									<!-- Start Single Product Column -->
									<div class="col-md-6">
										<div class="single-product">
											<div class="single-product-img">
												<a href="#">
													<img class="primary-img" src="img/product/sp3.jpg" alt="product">
													<img class="secondary-img" src="img/product/sp19.jpg" alt="product">
												</a>
											</div>
											<div class="single-product-content">
												<div class="product-content-head">
													<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
													<p class="product-price"><span>$205.00</span> $155.00</p>
												</div>
												<div class="product-bottom-action">
													<div class="product-action">
														<div class="action-button">
															<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
														</div>
														<div class="action-view">
															<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div><!-- End Single Product Column -->
									<!-- Start Single Product Column -->
									<div class="col-md-6">
										<div class="single-product">
											<div class="single-product-img">
												<a href="#">
													<img class="primary-img" src="img/product/sp2.jpg" alt="product">
													<img class="secondary-img" src="img/product/sp5.jpg" alt="product">
												</a>
											</div>
											<div class="single-product-content">
												<div class="product-content-head">
													<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
													<p class="product-price">$155.00</p>
												</div>
												<div class="product-bottom-action">
													<div class="product-action">
														<div class="action-button">
															<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
														</div>
														<div class="action-view">
															<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div><!-- End Single Product Column -->
									<!-- Start Single Product Column -->
									<div class="col-md-6">
										<div class="single-product">
											<div class="single-product-img">
												<a href="#">
													<img class="primary-img" src="img/product/sp6.jpg" alt="product">
													<img class="secondary-img" src="img/product/sp1.jpg" alt="product">
												</a>
											</div>
											<div class="single-product-content">
												<div class="product-content-head">
													<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
													<p class="product-price">$155.00</p>
												</div>
												<div class="product-bottom-action">
													<div class="product-action">
														<div class="action-button">
															<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
														</div>
														<div class="action-view">
															<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div><!-- End Single Product Column -->
								</div><!-- End Single Product Carousel -->
							</div>
						</div>
					</div><!-- End Brand Products Column -->
					<!-- Brand Product Column -->
					<div class="col-md-6 col-sm-6">
						<div class="brand-products c-carousel-button">
							<div class="row">
								<div class="col-md-12">
									<div class="products-head">
										<div class="products-head-title">
											<i class="fa fa-picture-o"></i>
											<h2>brand Bag</h2>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<!-- Single Product Carousel-->
								<div id="product-brand-bag" class="owl-carousel">
									<!-- Start Single Product Column -->
									<div class="col-md-6">
										<div class="single-product">
											<div class="single-product-img">
												<a href="#">
													<img class="primary-img" src="img/product/sp7.jpg" alt="product">
													<img class="secondary-img" src="img/product/sp8.jpg" alt="product">
												</a>
											</div>
											<div class="single-product-content">
												<div class="product-content-head">
													<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
													<p class="product-price">$155.00</p>
												</div>
												<div class="product-bottom-action">
													<div class="product-action">
														<div class="action-button">
															<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
														</div>
														<div class="action-view">
															<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div><!-- End Single Product Column -->
									<!-- Start Single Product Column -->
									<div class="col-md-6">
										<div class="single-product">
											<div class="single-product-img">
												<a href="#">
													<img class="primary-img" src="img/product/sp10.jpg" alt="product">
													<img class="secondary-img" src="img/product/sp5.jpg" alt="product">
												</a>
											</div>
											<div class="single-product-content">
												<div class="product-content-head">
													<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
													<p class="product-price"><span>$205.00</span> $155.00</p>
												</div>
												<div class="product-bottom-action">
													<div class="product-action">
														<div class="action-button">
															<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
														</div>
														<div class="action-view">
															<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div><!-- End Single Product Column -->
									<!-- Start Single Product Column -->
									<div class="col-md-6">
										<div class="single-product">
											<div class="single-product-img">
												<a href="#">
													<img class="primary-img" src="img/product/sp2.jpg" alt="product">
													<img class="secondary-img" src="img/product/sp5.jpg" alt="product">
												</a>
											</div>
											<div class="single-product-content">
												<div class="product-content-head">
													<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
													<p class="product-price">$155.00</p>
												</div>
												<div class="product-bottom-action">
													<div class="product-action">
														<div class="action-button">
															<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
														</div>
														<div class="action-view">
															<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div><!-- End Single Product Column -->
									<!-- Start Single Product Column -->
									<div class="col-md-6">
										<div class="single-product">
											<div class="single-product-img">
												<a href="#">
													<img class="primary-img" src="img/product/sp6.jpg" alt="product">
													<img class="secondary-img" src="img/product/sp1.jpg" alt="product">
												</a>
											</div>
											<div class="single-product-content">
												<div class="product-content-head">
													<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
													<p class="product-price">$155.00</p>
												</div>
												<div class="product-bottom-action">
													<div class="product-action">
														<div class="action-button">
															<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
														</div>
														<div class="action-view">
															<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div><!-- End Single Product Column -->
								</div><!-- End Single Product Carousel-->
							</div>
						</div>
					</div><!-- End Brand Product Column -->
				</div>
			</div>
		</div><!-- End Brand Product area -->
		<!-- About-add area -->
		<div class="about-add-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-3 col-sm-5">
						<div class="about-add-img banner-add">
							<a href="#">
								<img src="img/banner/b2.png" alt="img">
							</a>
						</div>
					</div>
					<div class="col-lg-4 col-md-5 col-sm-7">
						<div class="about-add-content">
							<div class="add-single-content">
								<div class="content-left">
									<div class="number">
										<span>1</span>
									</div>
								</div>
								<div class="content-right">
									<h2>Responsive design</h2>
									<p>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.</p>
								</div>
							</div>
							<div class="add-single-content">
								<div class="content-left">
									<div class="number">
										<span>2</span>
									</div>
								</div>
								<div class="content-right">
									<h2>Responsive design</h2>
									<p>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.</p>
								</div>
							</div>
							<div class="add-single-content">
								<div class="content-left">
									<div class="number">
										<span>3</span>
									</div>
								</div>
								<div class="content-right">
									<h2>Responsive design</h2>
									<p>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.</p>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-12">
						<div class="about-add-banner">
							<div class="about-add-banner-top banner-add">
								<a href="#">
									<img src="img/banner/b3.png" alt="img">
								</a>
							</div>
							<div class="about-add-banner-bottom banner-add">
								<div class="banner-bottom-left">
									<a href="#">
										<img src="img/banner/b4.png" alt="img">
									</a>
								</div>
								<div class="banner-bottom-right banner-add">
									<a href="#">
										<img src="img/banner/b5.png" alt="img">
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div><!-- End About-add area -->
		<!-- Fetured Product area -->
		<div class="fetured-product-area brand-products c-carousel-button">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="fetured-products">
							<div class="row">
								<div class="col-md-12">
									<div class="products-head">
										<div class="products-head-title">
											<i class="fa fa-picture-o"></i>
											<h2>Featured products</h2>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<!-- Fetured Product Carousel -->
					<div id="feture-products" class="owl-carousel">
						<div class="col-md-12 col-sm-12">
							<!-- Fetured Product Item area -->
							<div class="fitured-product-item-area">
								<div class="row">
									<!-- Fetured Product Inner Item Column -->
									<div class="col-lg-4 col-md-6 col-sm-6">
										<!-- Fetured Product Inner Item -->
										<div class="fiture-product-inner-item">
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f1.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f2.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"><span>$175.00</span> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f3.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f4.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
										</div><!-- End Fetured Product Inner Item -->
									</div><!-- End Fetured Product Inner Item Column -->
									<!-- Fetured Product Inner Item Column -->
									<div class="col-lg-4 col-md-6 col-sm-6 hidden-xs">
										<!-- Fetured Product Inner Item -->
										<div class="fiture-product-inner-item">
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f5.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f6.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f7.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f8.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"><span>$175.00</span> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
										</div><!-- End Fetured Product Inner Item -->
									</div><!-- End Fetured Product Inner Item Column -->
									<!-- Fetured Product Inner Item Column -->
									<div class="col-lg-4 col-md-6 hidden-md hidden-sm hidden-xs">
										<!-- Fetured Product Inner Item -->
										<div class="fiture-product-inner-item">
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f9.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f10.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"><span>$175.00</span> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f11.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f12.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"><span>$175.00</span> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
										</div><!-- End Fetured Product Inner Item -->
									</div><!-- End Fetured Product Inner Item Column -->
								</div>
							</div><!-- End Fetured Product Item area -->
						</div>
						<div class="col-md-12 col-sm-12">
							<!-- Fetured Product Item area -->
							<div class="fitured-product-item-area">
								<div class="row">
									<!-- Fetured Product Inner Item Column -->
									<div class="col-lg-4 col-md-6 col-sm-6">
										<!-- Fetured Product Inner Item -->
										<div class="fiture-product-inner-item">
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f2.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f1.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f4.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f3.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"><span>$175.00</span> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
										</div><!-- End Fetured Product Inner Item -->
									</div><!-- End Fetured Product Inner Item Column -->
									<!-- Fetured Product Inner Item Column -->
									<div class="col-lg-4 col-md-6 col-sm-6 hidden-xs">
										<!-- Fetured Product Inner Item -->
										<div class="fiture-product-inner-item">
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f6.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f5.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f8.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f7.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
										</div><!-- End Fetured Product Inner Item -->
									</div><!-- End Fetured Product Inner Item Column -->
									<!-- Fetured Product Inner Item Column -->
									<div class="col-md-6 col-lg-4 hidden-md hidden-sm hidden-xs">
										<!-- Fetured Product Inner Item -->
										<div class="fiture-product-inner-item">
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f10.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f9.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price"><span>$175.00</span> $155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
											<!-- Fetured Product Single Item -->
											<div class="fiture-poroduct-single-item">
												<div class="single-item-img">
													<a href="#">
														<img class="primary-img" src="img/product/feture-product/f12.jpg" alt="product">
														<img class="secondary-img" src="img/product/feture-product/f11.jpg" alt="product">
													</a>
												</div>
												<div class="single-item-content">
													<div class="content-head">
														<h2 class="product-title">
															<a href="#">Fusce aliquam</a>
														</h2>
														<p class="product-price">$155.00</p>
													</div>
													<div class="content-action">
														<button class="btn" type="button"><i class="fa fa-shopping-cart"></i></button>
														<ul>
															<li class="heart-li"><a href="#"><i class="fa fa-heart"></i></a></li>
															<li class="exchange-li"><a href="#"><i class="fa fa-exchange"></i></a></li>
															<li><a href="#" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i></a></li>
														</ul>
													</div>
												</div>
											</div><!-- End Fetured Product Single Item -->
										</div><!-- End Fetured Product Inner Item -->
									</div><!-- End Fetured Product Inner Item Column -->
								</div>
							</div><!-- End Fetured Product Item area -->
						</div>
					</div><!-- End Fetured Products Carousel -->
				</div>
			</div>
		</div><!-- End Fetured Product area -->
		<!-- Brand Logo area -->
		<div class="brand-logo-area">
			<div class="container">
				<div class="brand-logo">
					<div class="brand-logo-title">
						<h2>Logo brands</h2>
					</div>
					<div id="brands-logo" class="owl-carousel">
						<div class="single-brand-logo">
							<a href="#">
								<img src="<?php echo e(URL::to("assets/img/brand-logo/blogo1.png")); ?>" alt="logo">
							</a>
						</div>
						<div class="single-brand-logo">
							<a href="#">
								<img src="img/brand-logo/blogo5.png" alt="logo">
							</a>
						</div>
						<div class="single-brand-logo">
							<a href="#">
								<img src="img/brand-logo/blogo2.png" alt="logo">
							</a>
						</div>
						<div class="single-brand-logo">
							<a href="#">
								<img src="img/brand-logo/blogo3.png" alt="logo">
							</a>
						</div>
						<div class="single-brand-logo">
							<a href="#">
								<img src="img/brand-logo/blogo4.png" alt="logo">
							</a>
						</div>
						<div class="single-brand-logo">
							<a href="#">
								<img src="img/brand-logo/blogo1.png" alt="logo">
							</a>
						</div>
						<div class="single-brand-logo">
							<a href="#">
								<img src="img/brand-logo/blogo5.png" alt="logo">
							</a>
						</div>
						<div class="single-brand-logo">
							<a href="#">
								<img src="img/brand-logo/blogo3.png" alt="logo">
							</a>
						</div>
						<div class="single-brand-logo">
							<a href="#">
								<img src="img/brand-logo/blogo4.png" alt="logo">
							</a>
						</div>
						<div class="single-brand-logo">
							<a href="#">
								<img src="img/brand-logo/blogo2.png" alt="logo">
							</a>
						</div>
					</div>
				</div>
			</div>
		</div><!-- End Brand Logo area -->
		<!-- Footer area -->
		<div class="footer-area">
			<!-- Footer Top -->
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-md-4">
							<!-- Footer Left -->
							<div class="footer-left">
								<!-- Footer Logog -->
								<div class="footer-logo">
									<a href="index.html"><img src="img/logo/logo-footer.png" alt="logo"></a>
								</div>
								<div class="footer-static-content">
									<p>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram.</p>
								</div>
								<div class="footer-payment">
									<h2>Payments</h2>
									<ul>
										<li><a href="#"><img src="img/logo/payment.png" alt="payment"></a></li>
									</ul>
								</div>
							</div><!-- End Footer Left -->
						</div>
						<div class="col-md-8 footer-right-col">
							<!-- Footer Right -->
							<div class="footer-right">
								<div class="footer-newsletter">
									<form action="#">
										<h2>Newsletter</h2>
										<input type="text" title="Sign up for our newsletter" required>
										<button type="submit">Subscribe</button>
									</form>
								</div>
								<div class="information-link">
									<div class="single-information-link">
										<h2>Informations</h2>
										<ul>
											<li><a href="#">Sitemap</a></li>
											<li><a href="#">Privacy Policy</a></li>
											<li><a href="#">Your Account</a></li>
											<li><a href="#">Advanced Search</a></li>
											<li><a href="#">Contact Us</a></li>
										</ul>
									</div>
									<div class="single-information-link">
										<h2>other static link</h2>
										<ul>
											<li><a href="#">Product Recall</a></li>
											<li><a href="#">Gift Vouchers</a></li>
											<li><a href="#">Returns and Exchanges</a></li>
											<li><a href="#">Shipping Options</a></li>
											<li><a href="#">Help & FAQs</a></li>
										</ul>
									</div>
									<div class="single-information-link">
										<h2> My account </h2>
										<ul>
											<li><a href="#">My orders</a></li>
											<li><a href="#">My credit slips</a></li>
											<li><a href="#">My addresses</a></li>
											<li><a href="#">My personal info</a></li>
										</ul>
									</div>
								</div>
							</div><!-- End Footer Left -->
						</div>
					</div>
				</div>
			</div><!-- End Footer Top -->
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="container">
					<!-- Copyright -->
					<div class="copyright">
						<p>Copyright &copy; <a href="http://bootexperts.com/">BootExperts</a> All Rights Reserved.</p>
					</div>
				</div>
			</div><!-- End Footer Bottom -->
		</div><!-- End Footer area -->
		<!-- QUICKVIEW PRODUCT -->
		<div id="quickview-wrapper">
			<!-- Modal -->
			<div class="modal fade" id="productModal" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						</div>
						<div class="modal-body">
							<div class="modal-product">
								<div class="product-images">
									<div class="main-image images">
										<img alt="product" src="img/product/sp2.jpg">
									</div>
								</div><!-- .product-images -->
								
								<div class="product-info">
									<h1>Cras neque metus</h1>
									<div class="price-box">
										<p class="price"><span class="special-price"><span class="amount">$155.00</span></span></p>
									</div>
									<a href="product-details.html" class="see-all">See all features</a>
									<div class="quick-add-to-cart">
										<form method="post" class="cart">
											<div class="add-to-box add-to-box2">
											<div class="add-to-cart">
												<div class="input-content">
													<label for="qty">Qty:</label>
													<input type="button" value="-" onclick="var qty_el = document.getElementById('qty'); var qty = qty_el.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 0 ) qty_el.value--;return false;" class="qty-decrease">
													<input type="text" name="qty" id="qty" maxlength="12" value="1" title="Qty" class="input-text qty">
													<input type="button" value="+" onclick="var qty_el = document.getElementById('qty'); var qty = qty_el.value; if( !isNaN( qty )) qty_el.value++;return false;" class="qty-increase">
												</div>
												<button class="btn" type="button"><span>Add to cart</span></button>
											</div>
										</div>
										</form>
									</div>
									<div class="quick-desc">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla.
									</div>
									<div class="social-sharing">
										<div class="widget widget_socialsharing_widget">
											<h3 class="widget-title-modal">Share this product</h3>
											<ul class="social-icons">
												<li><a target="_blank" title="Facebook" href="#" class="facebook social-icon"><i class="fa fa-facebook"></i></a></li>
												<li><a target="_blank" title="Twitter" href="#" class="twitter social-icon"><i class="fa fa-twitter"></i></a></li>
												<li><a target="_blank" title="Pinterest" href="#" class="pinterest social-icon"><i class="fa fa-pinterest"></i></a></li>
												<li><a target="_blank" title="Google +" href="#" class="gplus social-icon"><i class="fa fa-google-plus"></i></a></li>
												<li><a target="_blank" title="LinkedIn" href="#" class="linkedin social-icon"><i class="fa fa-linkedin"></i></a></li>
											</ul>
										</div>
									</div>
								</div><!-- .product-info -->
							</div><!-- .modal-product -->
						</div><!-- .modal-body -->
					</div><!-- .modal-content -->
				</div><!-- .modal-dialog -->
			</div><!-- END Modal -->
		</div><!-- END QUICKVIEW PRODUCT -->
				
<?php $__env->stopSection(); ?>
		
		

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>