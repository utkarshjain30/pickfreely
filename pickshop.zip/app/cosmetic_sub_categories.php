<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cosmetic_sub_categories extends Model
{
    //
}
