<!-- Start Single Product Column -->
@foreach ($products as $product)

<div class="col-md-4 col-sm-4">
    <div class="single-product">
        <div class="single-product-img">
            <a href="/product/skuid={{$product->id}}">
                <img class="primary-img" src="{{Voyager::image(thumbnail(imageValidate($product->feature_image), 'medium'))}}" alt="product">
                <img class="secondary-img" src="{{Voyager::image(thumbnail(imageValidate($product->feature_image), 'medium'))}}" alt="product">
            </a>
        </div>
        <div class="single-product-content">
            <div class="product-content-head">
            <h2 class="product-title"><a href="#">{{$product->name}}</a></h2>
            <p class="product-price">Rs. {{$product->price}}.00/-</p>
            </div>
            <div class="product-bottom-action">
                <div class="product-action">
                    <div class="action-button">
                    <a class="btn" href="/cart/skuid={{$product->id}}"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></a>
                    </div>
                    <div class="action-view">
                        <button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Single Product Column -->

@endforeach