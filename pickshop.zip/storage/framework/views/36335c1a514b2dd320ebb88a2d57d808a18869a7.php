<!-- Header Cart Area-->
<div class="header-cart-area">
    <div class="header-cart">
        <ul>
            <li>
                <a href="#">
                    <i class="fa fa-shopping-cart"></i>
                    <span class="my-cart">My cart</span>
                    <?php $cartCollection = Cart::getContent(); ?>
                <span class="badge"><?php echo e($cartCollection->count()); ?></span>
                </a>
                <ul>
                    <li style="display:flex;flex-direction:column;">
                        <?php $subTotal=0;$grandTotal =0; ?>
                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $subTotal +=$item->getPriceSum();$grandTotal +=$item->getPriceSumWithConditions(); ?>
                        <div class="cart-list">
                            <div class="cart-list-item">
                                <div class="row">
                                <div class="cart-list-img col-3">
                                    <a href="#"><img src="<?php echo e(Voyager::image(thumbnail(imageValidate($item->attributes->image)))); ?>" alt="cart" style="height:50px;width:50px;" /></a>
                                </div>
                                <div class="cart-content col-6">
                                <a href="#"><?php echo e($item->name); ?></a>
                                <p>1 x <span>Rs. <?php echo e($item->price); ?>/-</span></p>
                                </div>
                                <div class="cart-button col-3">
                                    <a href="#"><i class="fa fa-pencil"></i></a>
                                    <a href="#"><i class="fa fa-times"></i></a>
                                </div>
                            </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="cart-subtotal">
                        <p>Subtotal: <span>Rs. <?php echo e($subTotal); ?>/-</span></p>
                        </div>
                        <div class="cart-action">
                            <button type="button" class="btn"><a href="/checkout"><span>checkout</span> <i class="fa fa-long-arrow-right"></a></i></button>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div><!-- End Header Cart Area-->