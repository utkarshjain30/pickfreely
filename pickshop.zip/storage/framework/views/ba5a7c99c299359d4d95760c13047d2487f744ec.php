<!-- Start Mobile Menu -->
<div class="mobile-menu hidden-md hidden-lg">
        <nav>
            <ul>
                <li class=""><a href="index.html">Home</a>
                    <ul class="sub-menu">
                        <li><a href="index-2.html">Home Page 2</a></li>
                        <li><a href="index-3.html">Home Page 3</a></li>
                        <li><a href="index-4.html">Home Page 4</a></li>
                        <li><a href="index-5.html">Home Page 5</a></li>
                        <li><a href="index-6.html">Home Page 6</a></li>
                    </ul>
                </li>
                <li><a href="shop.html">Women</a>
                    <ul class="">
                        <li><a href="">Clother</a>
                            <ul>
                                <li><a href="#">Cocktail</a></li>														
                                <li><a href="#">Day</a></li>
                                <li><a href="#">Evening</a></li>
                                <li><a href="#">Sports</a></li>
                                <li><a href="#">Sexy Dress</a></li>
                                <li><a href="#">Fsshion Skirt</a></li>
                                <li><a href="#">Evening Dress</a></li>
                                <li><a href="#">Children's Clothing</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Dress and skirt</a>
                            <ul>
                                <li><a href="#">Sports</a></li>														
                                <li><a href="#">Run</a></li>
                                <li><a href="#">Sandals</a></li>
                                <li><a href="#">Books</a></li>
                                <li><a href="#">A-line Dress</a></li>
                                <li><a href="#">Lacy Looks</a></li>
                                <li><a href="#">Shirts-T-Shirts</a></li>
                            </ul>
                        </li>
                        <li><a href="#">shoes</a>
                            <ul>
                                <li><a href="#">blazers</a></li>														
                                <li><a href="#">table</a></li>
                                <li><a href="#">coats</a></li>
                                <li><a href="#">Sports</a></li>
                                <li><a href="#">kids</a></li>
                                <li><a href="#">Sweater</a></li>
                                <li><a href="#">Coat</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class=""><a href="shop.html">Men</a>
                    <ul class="">
                        <li><a href="#">Bages</a>
                            <ul>
                                <li><a href="#">Bootes Bages</a></li>														
                                <li><a href="#">Blazers</a></li>
                                <li><a href="#">Mermaid</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Clothing</a>
                            <ul>
                                <li><a href="#">coats</a></li>														
                                <li><a href="#">T-shirt</a></li>
                            </ul>
                        </li>
                        <li><a href="#">lingerie</a>
                            <ul>
                                <li><a href="#">brands</a></li>														
                                <li><a href="#">furniture</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="shop.html">Handbags</a>
                    <ul class="">
                        <li><a href="#">Footwear Man</a>
                            <ul>
                                <li><a href="#">Gold Rigng</a></li>														
                                <li><a href="#">paltinum Rings</a></li>
                                <li><a href="#">Silver Ring</a></li>
                                <li><a href="#">Tungsten Ring</a></li>
                            </ul>	
                        </li>
                        <li><a href="#">Footwear Womens</a>
                            <ul>
                                <li><a href="#">Brand Gold</a></li>														
                                <li><a href="#">paltinum Rings</a></li>
                                <li><a href="#">Silver Ring</a></li>
                                <li><a href="#">Tungsten Ring</a></li>
                            </ul>	
                        </li>
                        <li><a href="#">Band</a>
                            <ul>
                                <li><a href="#">Platinum Necklaces</a></li>														
                                <li><a href="#">Gold Ring</a></li>
                                <li><a href="#">silver ring</a></li>
                                <li><a href="#">Diamond Bracelets</a></li>
                            </ul>	
                        </li>	
                    </ul>
                </li>
                <li><a href="shop.html">Shoes</a>
                    <ul class="">
                        <li><a href="#">Rings</a>
                            <ul>
                                <li><a href="#">Coats & jackets</a></li>														
                                <li><a href="#">blazers</a></li>
                                <li><a href="#">raincoats</a></li>
                            </ul>	
                        </li>
                        <li><a href="#">Dresses</a>
                            <ul>
                                <li><a href="#">footwear</a></li>														
                                <li><a href="#">blazers</a></li>
                                <li><a href="#">clog sandals</a></li>
                                <li><a href="#">combat boots</a></li>
                            </ul>	
                        </li>
                        <li><a href="#">Accessories</a>
                            <ul>
                                <li><a href="#">bootees Bags</a></li>														
                                <li><a href="#">blazers</a></li>
                                <li><a href="#">jackets</a></li>
                                <li><a href="#">kids</a></li>
                                <li><a href="#">shoes</a></li>
                            </ul>	
                        </li>
                        <li><a href="#">Top</a>
                            <ul>
                                <li><a href="#">briefs</a></li>														
                                <li><a href="#">camis</a></li>
                                <li><a href="#">nigthwear</a></li>
                                <li><a href="#">kids</a></li>
                                <li><a href="#">shapewer</a></li>
                            </ul>	
                        </li>
                    </ul>
                </li>
                <li class=""><a href="">Pages</a>
                    <ul class="">
                        <li><a href="blog.html">Blog</a></li>
                        <li><a href="blog-details.html">Blog Details</a></li>
                        <li><a href="cart.html">Cart</a></li>
                        <li><a href="checkout.html">Checkout</a></li>
                        <li><a href="contact.html">Contact</a></li>
                        <li><a href="shop.html">Shop</a></li>
                        <li><a href="shop-list.html">Shop List</a></li>
                        <li><a href="product-details.html">Product Details</a></li>
                        <li><a href="my-account.html">My Account</a></li>
                        <li><a href="wishlist.html">Wishlist</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div><!-- End Mobile Menu -->