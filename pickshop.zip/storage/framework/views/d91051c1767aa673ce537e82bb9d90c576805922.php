<!-- Start Mobile Menu -->
<div class="mobile-menu hidden-md hidden-lg">
        <nav>
            <ul>
                <li class=""><a href="index.html">Home</a></li>
                <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="javascript.void(0)"><?php echo e($item->name); ?></a>
                    <ul class="">
                        <?php $__currentLoopData = renderMainCategory($item->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                        <li><a href="javascript.void(0)"><?php echo e($mainitem->name); ?></a>
                            <ul>
                                <?php $__currentLoopData = renderSubCategory($mainitem->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="/list?subcat=<?php echo e($subitem->id); ?>"><?php echo e($subitem->name); ?></a></li>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>														
                            </ul>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </ul>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <li class=""><a href="">Pages</a>
                    <ul class="">
                        <li><a href="blog.html">Blog</a></li>
                        <li><a href="blog-details.html">Blog Details</a></li>
                        <li><a href="cart.html">Cart</a></li>
                        <li><a href="checkout.html">Checkout</a></li>
                        <li><a href="contact.html">Contact</a></li>
                        <li><a href="shop.html">Shop</a></li>
                        <li><a href="shop-list.html">Shop List</a></li>
                        <li><a href="product-details.html">Product Details</a></li>
                        <li><a href="my-account.html">My Account</a></li>
                        <li><a href="wishlist.html">Wishlist</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div><!-- End Mobile Menu -->