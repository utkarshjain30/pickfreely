
                    <!-- Main Menu -->
                    <div class="main-menu hidden-sm hidden-xs">
                        <nav>
                            <ul class="main-ul">
                                <li class="sub-menu-li"><a href="index.html" class="active">Home<i class="fa fa-chevron-down"></i></a>
                                    <!-- Sub Menu -->
                                    <ul class="sub-menu">
                                        <li><a href="index-2.html"><i class="fa fa-chevron-circle-right"></i> <span>Home Page 2</span></a></li>
                                        <li><a href="index-3.html"><i class="fa fa-chevron-circle-right"></i> <span>Home Page 3</span></a></li>
                                        <li><a href="index-4.html"><i class="fa fa-chevron-circle-right"></i> <span>Home Page 4</span></a></li>
                                        <li><a href="index-5.html"><i class="fa fa-chevron-circle-right"></i> <span>Home Page 5</span></a></li>
                                        <li><a href="index-6.html"><i class="fa fa-chevron-circle-right"></i> <span>Home Page 6</span></a></li>
                                    </ul>
                                </li>
                                <li><a href="shop.html"><span class="label-menu">Sale</span> Women<i class="fa fa-chevron-down"></i></a>
                                    <ul class="mega-menu-ul">
                                        <li>
                                            <!-- Mega Menu -->
                                            <div class="mega-menu">
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Clother</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Cocktail</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Day</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Evening</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Sports</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Sexy Dress</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Fsshion Skirt</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Evening Dress</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Children's Clothing</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Dress and skirt</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Sports</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Run</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Sandals</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Books</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>A-line Dress</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Lacy Looks</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Shirts-T-Shirts</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">shoes</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>blazers</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>table</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>coats</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>kids</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Sweater</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Coat</span></a>
                                                </div>
                                                <div class="single-mega-menu banner-add">
                                                    <a href="shop.html">
                                                        <img src="img/cart/menu-img.png" alt="img">
                                                    </a>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li class="small-megamenu-li"><a href="shop.html">Men<i class="fa fa-chevron-down"></i></a>
                                    <ul class="mega-menu-ul mega-menu-ul-two">
                                        <li>
                                            <!--Small Mega Menu -->
                                            <div class="mega-menu mega-menu-two">
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Bages</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Bootes Bages</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Blazers</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Mermaid</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Clothing</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>coats</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>T-shirt</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">lingerie</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>brands</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>furniture</span></a>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="shop.html">Handbags<i class="fa fa-chevron-down"></i></a>
                                    <ul class="mega-menu-ul">
                                        <li>
                                            <!-- Mega Menu -->
                                            <div class="mega-menu">
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Footwear Man</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Gold Rigng</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>paltinum Rings</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Silver Ring</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Tungsten Ring</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Footwear Womens</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Bands Gold</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>platinum Bands</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Silver Bands</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Tungsten Bands</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Rings</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Platinum Bracelets</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Gold Ring</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>silver ring</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Diamond Bracelets</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Band</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Platinum Necklaces</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Gold Ring</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Silver Ring</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Sunglasses</span></a>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="shop.html">Shoes<i class="fa fa-chevron-down"></i></a>
                                    <ul class="mega-menu-ul">
                                        <li>
                                            <!-- Mega Menu -->
                                            <div class="mega-menu">
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Rings</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Coats & jackets</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>blazers</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>raincoats</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Dresses</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Ankle Boots</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>footwear</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>clog sandals</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>combat boots</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Accessories</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>bootees Bags</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>blazers</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>jackets</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>kids</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>shoes</span></a>
                                                </div>
                                                <div class="single-mega-menu">
                                                    <h2><a href="shop.html">Top</a></h2>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>briefs</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>camis</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>nigthwear</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>kids</span></a>
                                                    <a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>shapewer</span></a>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu-li"><a href="#" class="new-arrivals">Pages<i class="fa fa-chevron-down"></i></a>
                                    <!-- Sub Menu -->
                                    <ul class="sub-menu">
                                        <li><a href="blog.html"><i class="fa fa-chevron-circle-right"></i> <span>Blog</span></a></li>
                                        <li><a href="blog-details.html"><i class="fa fa-chevron-circle-right"></i> <span>Blog Details</span></a></li>
                                        <li><a href="cart.html"><i class="fa fa-chevron-circle-right"></i> <span>Cart</span></a></li>
                                        <li><a href="checkout.html"><i class="fa fa-chevron-circle-right"></i> <span>Checkout</span></a></li>
                                        <li><a href="contact.html"><i class="fa fa-chevron-circle-right"></i> <span>Contact</span></a></li>
                                        <li><a href="shop.html"><i class="fa fa-chevron-circle-right"></i> <span>Shop</span></a></li>
                                        <li><a href="shop-list.html"><i class="fa fa-chevron-circle-right"></i> <span>Shop List</span></a></li>
                                        <li><a href="product-details.html"><i class="fa fa-chevron-circle-right"></i> <span>Product Details</span></a></li>
                                        <li><a href="my-account.html"><i class="fa fa-chevron-circle-right"></i> <span>My Account</span></a></li>
                                        <li><a href="wishlist.html"><i class="fa fa-chevron-circle-right"></i> <span>Wishlist</span></a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div><!-- End Main Menu -->
                    