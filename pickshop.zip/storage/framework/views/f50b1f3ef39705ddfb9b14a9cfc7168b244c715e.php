<?php $__env->startSection('test'); ?>
    <div class="test">
        <h1>TESTTTTT</h1>
<?php echo $__env->yieldSection(); ?>
</div>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>