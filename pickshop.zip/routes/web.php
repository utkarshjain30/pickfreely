<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','IndexController@index');

//List Routes
Route::get('/list', 'ListController@index');
Route::get('/list/{selector}/id={id}', 'ListController@show');

Route::get('/product', 'ProductController@index');
Route::get('/product/skuid={id}', 'ProductController@show');

Route::get('/login', function () {
    return view('login');
});
Route::get('/checkout', function () {
    return view('checkout');
});
Route::get('/account', function () {
    return view('my-account');
});


//Cart Controllers
Route::post('/cart/skuid={id}', 'CartController@addProduct');
Route::get('/cart', 'CartController@index');

//Checkout Controllers
Route::post('/confirm', 'Checkout@confirm');

//Admin Controllers
Route::group(['prefix' => 'admin'], function () {
    Voyager::routes();
});
