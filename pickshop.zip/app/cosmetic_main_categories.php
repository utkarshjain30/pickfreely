<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cosmetic_main_categories extends Model
{
    //
}
