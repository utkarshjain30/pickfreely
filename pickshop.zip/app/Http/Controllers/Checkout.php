<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Cart;
use App\order;

class Checkout extends Controller
{
    //
    public function confirm(Request $request){
        $cart = Cart::getContent();
        $array = ['info'=>$request,'cart'=>$cart];
        return $request;
    }
}
