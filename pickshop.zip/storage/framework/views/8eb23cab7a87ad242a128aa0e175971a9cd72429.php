<!-- Tab Pane Two -->
<div class="tab-pane" id="p-new">
        <div class="row">
            <!-- Single Product Carousel-->
            <div id="single-product-new" class="owl-carousel">
                <!-- Start Single Product Column -->
                <?php $__currentLoopData = showNewProduct(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <div class="col-md-3">
                    <div class="single-product">
                        <div class="single-product-img">
                            <a href="/product/skuid=<?php echo e($item->id); ?>">
                                <img class="primary-img" src="<?php echo e(Voyager::image(thumbnail(imageValidate($item->feature_image) ,'cropped'))); ?>" alt="product">
                                <img class="secondary-img" src="img/product/sp12.jpg" alt="product">
                            </a>
                            <div class="product-status">
                                <span class="product-sale">Sale</span>
                            </div>
                        </div>
                        <div class="single-product-content">
                            <div class="product-content-head">
                            <h2 class="product-title"><a href="#"><?php echo e($item->name); ?></a></h2>
                                <p class="product-price">Rs. <?php echo e($item->price); ?></p>
                            </div>
                            <div class="product-bottom-action">
                                <div class="product-action">
                                    <div class="action-button">
                                        <button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- End Single Product Column -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div><!-- End Single Product Carousel-->
        </div>
    </div><!-- End Tab Pane Two -->