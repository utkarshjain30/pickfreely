<!-- Start Cart Item -->
<div class="chart-item table-responsive fix">
    <table class="col-md-12">
        <thead>
            <tr>
                <th class="th-delate">Remove</th>
                <th class="th-product">Images</th>
                <th class="th-details">Product Name</th>
                <th class="th-edit">Edit</th>
                <th class="th-price">Unit Price</th>
                <th class="th-qty">Qty</th>
                <th class="th-total">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="th-delate"><a href="#">X</a></td>
                <td class="th-product">
                    <a href="#"><img src="<?php echo e(Voyager::image(thumbnail(imageValidate($item->attributes->image)))); ?>" alt="cart"></a>
                </td>
                <td class="th-details">
                    <h2><a href="#"><?php echo e($item->name); ?></a></h2>
                </td>
                <td class="th-edit"><a href="#">Edit</a></td>
            <td class="th-price">Rs. <?php echo e($item->price); ?>/-</td>
                <td class="th-qty">
                <input type="text" placeholder="<?php echo e($item->quantity); ?>">
                </td>
            <td class="th-total">Rs. <?php echo e($item->getPriceSum()); ?>/-</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><!-- End Cart Item -->
    