<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cosmetic_categories extends Model
{
    //
}
