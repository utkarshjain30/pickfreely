<!-- Start Single Product Column -->
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-md-4 col-sm-4">
    <div class="single-product">
        <div class="single-product-img">
            <a href="/product/skuid=<?php echo e($product->id); ?>">
                <img class="primary-img" src="<?php echo e(Voyager::image(thumbnail(imageValidate($product->feature_image), 'medium'))); ?>" alt="product">
                <img class="secondary-img" src="<?php echo e(Voyager::image(thumbnail(imageValidate($product->feature_image), 'medium'))); ?>" alt="product">
            </a>
        </div>
        <div class="single-product-content">
            <div class="product-content-head">
            <h2 class="product-title"><a href="#"><?php echo e($product->name); ?></a></h2>
            <p class="product-price">Rs. <?php echo e($product->price); ?>.00/-</p>
            </div>
            <div class="product-bottom-action">
                <div class="product-action">
                    <div class="action-button">
                    <a class="btn" href="/cart/skuid=<?php echo e($product->id); ?>"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></a>
                    </div>
                    <div class="action-view">
                        <button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Single Product Column -->

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>