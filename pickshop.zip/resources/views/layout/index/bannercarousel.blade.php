<!-- Main Slider Area -->
<div class="main-slider-area">
<!-- Main Slider -->
<div class="main-slider">
    <div class="slider">
        <div id="mainSlider" class="nivoSlider">
            @foreach ($Banners as $item)
            <a href="/brand/id={{$item->product}}">
                    <img src="{{Voyager::image(imageValidate($item->image))}}" alt="main slider" title="#htmlcaption1"/>
                </a>
            @endforeach            
        </div>
        
    </div>
</div><!-- End Main Slider -->
</div><!-- End Main Slider Area -->