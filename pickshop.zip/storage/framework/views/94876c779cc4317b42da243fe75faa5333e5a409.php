<div class="shop-product-left">
        <!-- Shop Layout Area -->
        <div class="shop-layout-area">
            <div class="layout-title">
                <h2>Category</h2>
            </div>
            <div class="layout-list">
                <ul>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="#"><i class="fa fa-plus-square-o"></i><?php echo e($category->name); ?> <span>(15)</span></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Cocktail <span>(15)</span></a></li>
                </ul>
            </div>
        </div><!-- End Shop Layout Area -->
        <!-- Price Filter Area -->
        <div class="price-filter-area shop-layout-area">
            <div class="price-filter">
                <div class="layout-title">
                    <h2>Price</h2>
                </div>
                <div id="slider-range"></div>
                <p>
                  <input type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;">
                </p>
                <button class="btn btn-default">Filter</button>
            </div>
        </div><!-- End Price Filter Area -->
        <!-- Shop Layout Area -->
        <div class="shop-layout-area">
            <div class="layout-title">
                <h2>Manufacturer</h2>
            </div>
            <div class="layout-list">
                <ul>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Adidas <span>(1)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Chanel <span>(1)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>DKNY <span>(2)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Dolce <span>(2)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Gabbana <span>(3)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Nike<span>(1)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Vogue <span>(3)</span></a></li>
                </ul>
            </div>
        </div><!-- End Shop Layout Area -->
        <!-- Shop Layout Area -->
        <div class="shop-layout-area">
            <div class="layout-title">
                <h2>Color</h2>
            </div>
            <div class="layout-list">
                <ul>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Black <span>(1)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Blue <span>(2)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Brown <span>(1)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Pink <span>(3)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Red <span>(3)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>While<span>(2)</span></a></li>
                    <li><a href="#"><i class="fa fa-plus-square-o"></i>Yellow <span>(1)</span></a></li>
                </ul>
            </div>
        </div><!-- End Shop Layout Area -->
        <!-- Shop Layout Area -->
        <div class="shop-layout-area">
            <div class="layout-title">
                <h2>Compare</h2>
                <p>You have no items to compare.</p>
            </div>
            <div class="popular-tag">
                <h2>Popular Tags</h2>
                <div class="tag-list">
                    <ul>
                        <li><a href="#">Clothing</a></li>
                        <li><a href="#">accessories</a></li>
                        <li><a href="#">fashion</a></li>
                        <li><a href="#">footwear</a></li>
                        <li><a href="#">good</a></li>
                        <li><a href="#">kid</a></li>
                        <li><a href="#">Men</a></li>
                        <li><a href="#">Women</a></li>
                    </ul>
                </div>
                <div class="tag-action">
                    <ul>
                        <li><a href="#">View all tags</a></li>
                    </ul>
                </div>
            </div>
            <div class="shop-layout-banner banner-add">
                <a href="#">
                    <img alt="banner" src="img/banner/b18.jpg">
                </a>
            </div>
        </div><!-- End Shop Layout Area -->
    </div>