<!-- Main Slider Area -->
<div class="main-slider-area">
<!-- Main Slider -->
<div class="main-slider">
    <div class="slider">
        <div id="mainSlider" class="nivoSlider">
            <?php $__currentLoopData = $Banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/brand/id=<?php echo e($item->product); ?>">
                    <img src="<?php echo e(Voyager::image(imageValidate($item->image))); ?>" alt="main slider" title="#htmlcaption1"/>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </div>
        
    </div>
</div><!-- End Main Slider -->
</div><!-- End Main Slider Area -->