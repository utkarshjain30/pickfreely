<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\cosmetic_categories;
use App\cosmetic_main_categories;
use App\cosmetic_sub_categories;
use App\Product;
use App\brand;


class ListController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // var $paginateAmount = 15;
    
    public function index(Request $request)
    {
        $categories = cosmetic_main_categories::all();
        $sub_categories = cosmetic_sub_categories::all();
        $products = Product::all();
        $brands = brand::all();
        
        if(request()->has('brand')){
            $id = $request['brand'];
            $products = Product::where('id',$id)->paginate(15)->appends('brand',$id);
        }
        elseif(request()->has('category')){
            $id = $request['category'];
            $products = Product::where('main_category',$id)->paginate(15)->appends('category',$id);
        }
        elseif(request()->has('price'))
        {
            $id = $request['price'];
            return $id;
            
        }

        return view('list',compact('categories', 'sub_categories', 'products', 'brands'));
        // return $query;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        return $request;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $name , $id)
    {
        //
        $query = $name->all();
        $categories = cosmetic_categories::all();
        $brands = brand::all();

        $products = $name.'/'.$id;
        if($name == 'maincategory' || $name == 'main_category' || $name == 'maincategories' || $name == 'main_categories'){
            $products = Product::where('main_category', $id)->get();
        }
        elseif ($name == 'subcategory' || $name == 'sub_category' || $name == 'subcategories' || $name == 'sub_categories') {
            $products = Product::where('sub_category', $id)->get();
        }
        elseif ($name == 'brand') {
            $products = Product::where('brand', $id)->get();
        }
        return view('list',compact('categories','products', 'brands'));
        // return $query;

    }
   
}
