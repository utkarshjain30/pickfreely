@extends('layout.app')

@section('contents')
	

        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		@include('layout.index.bannercarousel')		
		<!-- Product Box Area -->
		<div class="product-box-area">
			<div class="container">
				<!-- Product Box -->
				<div class="product-box">
					<!-- Single Product Box -->
					<div class="single-product-box">
						<div class="product-box-img">
							<a href="/list?category=1"><img src="{{URL::to("assets/img/product-box/pb1.png")}}" alt="product"></a>							
						</div>
						<div class="product-box-content">				
							<h2>MakeUp</h2>
							<p>Fashiong trending <?php date('Y');?></p>
							<a href="/list?category=1">shop now</a>
						</div>
					</div>
					<!-- Single Product Box -->
					<div class="single-product-box single-product-box-two">
						<div class="product-box-content">				
							<h2>Skin</h2>
							<p>trending </p>
							<a href="/list?category=2">shop now</a>
						</div>
						<div class="product-box-img">
							<a href="/list?category=2"><img src="{{URL::to("assets/img/product-box/pb2.png")}}" alt="product"></a>							
						</div>
					</div>
					<!-- Single Product Box -->
					<div class="single-product-box single-product-box-three">
						<div class="product-box-img">
							<a href="/list?category=3"><img src="{{URL::to("assets/img/product-box/pb3.png")}}" alt="product"></a>							
						</div>
						<div class="product-box-content">				
							<h2>Hair</h2>
							<p>Fashiong trending</p>
							<a href="/list?category=3">shop now</a>
						</div>
					</div>
				</div><!-- End Product Box -->
			</div>
		</div><!-- End Product Box Area -->
		<!-- Product area -->
		<div class="product-area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<!-- Product Top Bar -->
						<div class="product-top-bar customize-tab-bar">
							<!-- Tab Button -->
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation" class="active"><a href="#p-bestseller" data-toggle="tab"><i class="fa fa-pencil-square-o"></i>bestseller</a></li>
								<li role="presentation"><a href="#p-new" data-toggle="tab"><i class="fa fa-star"></i>New Products</a></li>
								<li role="presentation"><a href="#p-random" data-toggle="tab"><i class="fa fa-picture-o"></i>Random Products</a></li>
							</ul><!-- End Tab Button -->
						</div><!-- End Product Top Bar -->
					</div>
					<div class="col-md-12">
						<!-- Single Product area -->
						<div class="single-product-area c-carousel-button">	
							<!-- Tab Content -->
							<div class="tab-content">
								@include('layout.index.bestseller')
								@include('layout.index.newarrival')

								
								<!-- Tab Pane Three -->
								<div role="tabpanel" class="tab-pane" id="p-random">
									<div class="row">
										<!-- Single Product Carousel-->
										<div id="single-product-random" class="owl-carousel">
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp20.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp21.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp17.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp11.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price"><span>$205.00</span> $155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp10.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp2.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp16.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp20.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price"><span>$80.00</span> $65.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp18.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp19.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp11.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp21.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-sale">Sale</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp1.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp2.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
											<!-- Start Single Product Column -->
											<div class="col-md-3">
												<div class="single-product">
													<div class="single-product-img">
														<a href="#">
															<img class="primary-img" src="img/product/sp13.jpg" alt="product">
															<img class="secondary-img" src="img/product/sp5.jpg" alt="product">
														</a>
														<div class="product-status">
															<span class="product-new">New</span>
														</div>
													</div>
													<div class="single-product-content">
														<div class="product-content-head">
															<h2 class="product-title"><a href="#">Cras neque metus</a></h2>
															<p class="product-price">$155.00</p>
														</div>
														<div class="product-bottom-action">
															<div class="product-action">
																<div class="action-button">
																	<button class="btn" type="button"><i class="fa fa-shopping-cart"></i> <span>Add to bag</span></button>
																</div>
																<div class="action-view">
																	<button type="button" class="btn" data-toggle="modal" data-target="#productModal"><i class="fa fa-search"></i>Quick view</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div><!-- End Single Product Column -->
										</div><!-- End Single Product Carousel-->
									</div>
								</div><!-- End Tab Pane Three -->
							</div><!-- End Tab Content -->
						</div><!-- End Single Product area -->
					</div>
				</div>
			</div>
		</div><!-- End Product area -->

		<!-- Single Banner area -->
		<div class="single-banner-area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="singler-banner banner-add">
							<a href="#">
								<img src="{{Voyager::image(imageValidate($Banners[0]->image))}}" alt="banner">
							</a>
						</div>
					</div>
				</div>
			</div>
		</div><!-- End Single Banner area -->
		
		@include('layout.index.featuredproduct')<!-- Featured Product -->

		<!-- About-add area -->
		<div class="about-add-area home-2-add-area">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-sm-6">
						<div class="about-add-img banner-add">
							<a href="#">
								<img src="{{asset("assets/img/banner/b6.png")}}" alt="img">
							</a>
						</div>
					</div>
					<div class="col-md-4 col-sm-6">
						<div class="about-add-img about-add-img-top banner-add">
							<a href="#">
								<img src="{{asset("assets/img/banner/b7.png")}}" alt="img">
							</a>
						</div>
						<div class="about-add-img banner-add">
							<a href="#">
								<img src="{{asset("assets/img/banner/b8.png")}}" alt="img">
							</a>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 hidden-sm">
						<div class="about-add-img about-add-img-top banner-add">
							<a href="#">
								<img src="{{asset("assets/img/banner/b9.png")}}" alt="img">
							</a>
						</div>
						<div class="about-add-img banner-add">
							<a href="#">
								<img src="{{asset("assets/img/banner/b10.png")}}" alt="img">
							</a>
						</div>
					</div>
				</div>
			</div>
		</div><!-- End About-add area -->

<!-- Support area -->
<div class="support-area">
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4">
				<!-- Single Support area -->
				<div class="single-support">
					<div class="single-support-icon">
						<p><i class="fa fa-bus"></i></p>
					</div>
					<div class="single-support-content">
						<h2>FREE DELIVERY ORDERS</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque convallis hendrerit nulla et hendrerit. Vivamus vitae vehicula odio. Proin nec varius nunc.</p>
					</div>
				</div><!-- End Single Support area -->
			</div>
			<div class="col-md-4 col-sm-4">
				<!-- Single Support area -->
				<div class="single-support">
					<div class="single-support-icon">
						<p><i class="fa fa-gift"></i></p>
					</div>
					<div class="single-support-content">
						<h2>FREE DELIVERY ORDERS</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque convallis hendrerit nulla et hendrerit. Vivamus vitae vehicula odio. Proin nec varius nunc.</p>
					</div>
				</div><!-- End Single Support area -->
			</div>
			<div class="col-md-4 col-sm-4">
				<!-- Single Support area -->
				<div class="single-support">
					<div class="single-support-icon">
						<i class="fa fa-fax"></i>
					</div>
					<div class="single-support-content">
						<h2>FREE DELIVERY ORDERS</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque convallis hendrerit nulla et hendrerit. Vivamus vitae vehicula odio. Proin nec varius nunc.</p>
					</div>
				</div><!-- End Single Support area -->
			</div>
		</div>
	</div>
</div><!-- End Support area -->

				
@endsection{{-- Laravel Section end --}}
		
		
