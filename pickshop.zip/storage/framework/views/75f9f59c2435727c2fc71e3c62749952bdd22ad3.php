


<!-- Main Menu -->
<div class="main-menu hidden-sm hidden-xs">
    <nav>
        <ul class="main-ul">
            <li class="sub-menu-li"><a href="/" class="active">Home</a>
            </li>
            <li><a href="javascript.void(0)">Categories<i class="fa fa-chevron-down"></i></a>
                <ul class="mega-menu-ul">
                    <li>
                        <!-- Mega Menu -->
                        <div class="mega-menu">
                            <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-mega-menu">
                            <h2><a href="/list?category=<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a></h2>
                           <?php $__currentLoopData = renderMainCategory($category->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/list?category=<?php echo e($category->id); ?>&maincategory=<?php echo e($mainitem->id); ?>"><i class="fa fa-chevron-circle-right"></i> <span><?php echo e($mainitem->name); ?></span></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </li>
                </ul>
            </li>
            
            <li class="sub-menu-li"><a href="javascript.void(0)" class="new-arrivals">Brands<i class="fa fa-chevron-down"></i></a>
                <!-- Sub Menu -->
                <ul class="sub-menu">
                    <?php $__currentLoopData = $Brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/list?brand=<?php echo e($item->id); ?>"><i class="fa fa-chevron-circle-right"></i> <span><?php echo e($item->name); ?></span></a></li>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li class="sub-menu-li"><a href="/contact" class="">Contact</a></li>
            <?php if(Auth::guard('customer')->check()): ?>
        <li class="sub-menu-li"><a href="#" class="">Hello &nbsp;<?php echo e(Auth::guard('customer')->user()->name); ?><i class="fa fa-chevron-down"></i></a>
                    <ul class="sub-menu">
                        <li><a href="/account/id=<?php echo e(Auth::guard('customer')->user()->id); ?>"><i class="fa fa-chevron-circle-right"></i> <span>My Account</span></a></li>
                        <li><a href="/account/id=<?php echo e(Auth::guard('customer')->user()->id); ?>"><i class="fa fa-chevron-circle-right"></i> <span>My Orders</span></a></li>
                        <li><a href="/account/id=<?php echo e(Auth::guard('customer')->user()->id); ?>"><i class="fa fa-chevron-circle-right"></i> <span>My Wishlist</span></a></li>
                        <li><a href="/account/id=<?php echo e(Auth::guard('customer')->user()->id); ?>"><i class="fa fa-chevron-circle-right"></i> <span>My Wallet</span></a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('customer.logout')); ?>"
                            onclick="event.preventDefault();
                                              document.getElementById('logout-form').submit();">
                             <i class="fa fa-chevron-circle-right"></i><?php echo e(__('Logout')); ?></a>

                         <form id="logout-form" action="<?php echo e(route('customer.logout')); ?>" method="POST" style="display: none;">
                             <?php echo csrf_field(); ?>
                         </form>
                        </li>
                    </ul>
                </li>                
            <?php else: ?>
            <li class="sub-menu-li"><a href="/login" class="">Login/register<i class="fa fa-chevron-down"></i></a></li>
            <?php endif; ?>           
        </ul>
    </nav>
</div><!-- End Main Menu -->
                    