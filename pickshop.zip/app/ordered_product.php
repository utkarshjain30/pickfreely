<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ordered_product extends Model
{
    //
    protected $table='ordered_product';
}
