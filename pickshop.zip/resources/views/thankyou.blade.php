@extends('layout.app')
@section('contents')
	 <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
	<div class="container">
		Sucessfully send your message! Thank You.
	</div>
@endsection
 
